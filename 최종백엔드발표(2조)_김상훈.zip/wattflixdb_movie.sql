-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: wattflixdb
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie` (
  `movieNo` varchar(10) NOT NULL,
  `movieTitle` varchar(50) NOT NULL,
  `movieGenre` varchar(10) DEFAULT NULL,
  `moviePoster` varchar(200) DEFAULT NULL,
  `movieEngTitle` varchar(50) DEFAULT NULL,
  `movieDirector` varchar(20) DEFAULT NULL,
  `movieActor` varchar(50) DEFAULT NULL,
  `movieRating` varchar(10) DEFAULT NULL,
  `movieOpenDate` varchar(15) DEFAULT NULL,
  `movieDetail` varchar(600) DEFAULT NULL,
  `movieStillcut` varchar(500) DEFAULT NULL,
  `movieTeaser` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`movieNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES ('1001','그린북','드라마','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000081/81532/81532_1000.jpg','','','','','','','',''),('1002','가버나움','드라마','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000081/81558/81558_1000.jpg','','','','','','','',''),('1003','원더','드라마','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000080/80428/80428_1000.jpg','','','','','','','',''),('1004','쉰들러 리스트','역사','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000081/81568/81568_1000.jpg','','','','','','','',''),('1005','매트릭스','판타지','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85541/85541_1000.jpg','','','','','','','',''),('1006','쇼생크 탈출','드라마','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000078/78753/78753_1000.jpg','','','','','','','',''),('1007','클래식','로맨틱','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000006/6942/6942_1000.jpg','','','','','','','',''),('1008','빽 투 더 퓨쳐','액션','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000078/78540/78540_1000.jpg','Back To The Future','로버트 저메키스','마이클 J.폭스,크리스토퍼 로이드,리 톰슨','','','','',''),('1009','죽은 시인의 사회','드라마','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000061/61436/61436_1000.jpg','','','','','','','',''),('1010','다크나이트 라이즈','액션','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000076/76417/76417_1000.jpg','Dark Knight Rises','크리스토퍼 놀란','크리스찬 베일,게리 올드만,앤 해서웨이','','','','',''),('1011','마녀','액션','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000080/80789/80789_1000.jpg','The Witch : Part 1. The Subversion','박훈정','김다미,조민수,박희순이','','','','',''),('1012','범죄도시 2','액션','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85813/85813_1000.jpg','The Roundup','이상용','마동석,손석구,최귀화','','','','',''),('1013','씽2게더','모험','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000084/84780/84780_1000.jpg','','','','','','','',''),('1014','쥬만지 - 새로운 세계','모험','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000079/79927/79927_1000.jpg','','','','','','','',''),('1015','쥬라기 월드 - 도미니언','모험','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85689/85689_1000.jpg','','','','','','','',''),('1016','탑건 - 매버릭','액션','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000082/82120/82120_1000.jpg','Top Gun: Maverick','조셉 코신스키','톰 크루즈,마일즈 텔러,제니퍼 코넬리','','','','',''),('1017','모어','모험','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85922/85922_1000.jpg','','','','','','','',''),('1018','실종','공포','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85917/85917_1000.jpg','Missing','가타야마 신조','사토 지로, 이토 아오이, 시미즈 히로야','','','','',''),('1019','룸 쉐어링','코미디','https://movie-phinf.pstatic.net/20220608_157/1654654613441kSez5_JPEG/movie_image.jpg','My Perfect Roommate','이순성','나문희,최우성,최선자','','','','',''),('1020','과속스캔들','코미디','http://t1.daumcdn.net/cfile/156F5710B20761D4F5','Scandal Makers','강형철','차태현,박보영,왕석현','','','','',''),('1021','오! 문희','코미디','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000083/83657/83657_1000.jpg','Oh! My Gran','정세교','나문희,이희준,최원영','','','','',''),('1022','스파이','코미디','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000078/78240/78240_1000.jpg','Spy','폴 페이그','주드 로,제이슨 스타뎀,멜리사 멕카시','','','','',''),('1023','박수건달','코미디','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000076/76726/76726_1000.jpg','Man on the Edge','조진규','박신양,김정태,엄지원','','','','',''),('1024','컨저링','공포','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000077/77140/77140_1000.jpg','','','','','','','',''),('1025','랑종','공포','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000084/84776/84776_1000.jpg','','','','','','','',''),('1026','곡성','공포','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000078/78885/78885_1000.jpg','','','','','','','',''),('1027','곤지암','공포','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000080/80557/80557_1000.jpg','','','','','','','',''),('1028','1917','역사','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000083/83065/83065_1000.jpg','','','','','','','',''),('1029','안시성','역사','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000080/80963/80963_1000.jpg','','','','','','','',''),('1030','인생은 아름다워','역사','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000060/60505/60505_1000.jpg','','','','','','','',''),('1031','덩케르크','역사',' https://img.cgv.co.kr/Movie/Thumbnail/Poster/000079/79729/79729_1000.jpg','','','','','','','',''),('1032','헤어질 결심','로맨틱','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85852/85852_1000.jpg','','','','','','','',''),('1033','러브 액츄얼리','로맨틱','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000009/9555/9555_1000.jpg','','','','','','','',''),('1034','그 시절 우리가 좋아했던 소녀','로맨틱','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000076/76521/76521_1000.jpg','','','','','','','',''),('1035','뷰티 인사이드','로맨틱','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000078/78338/78338_1000.jpg','','','','','','','',''),('1036','캐리비안의 해적 - 죽은 자는 말이 없다','모험','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000079/79598/79598_1000.jpg','Pirates of the Caribbean - Dead Men Tell No Tales','요아킴 뢰닝','조니 뎁, 하비에르 바르뎀, 브렌튼 스웨이츠','12세 이상','2017-05-24','죽음마저 집어삼킨 복수가 시작된다!<br><br><br>전설적인 해적 캡틴 ‘잭 스패로우’(조니 뎁)의 눈 앞에 죽음마저 집어삼킨 바다의 학살자 ‘살라자르’(하비에르 바르뎀)가 복수를 위해 찾아온다.<br><br>둘 사이에 숨겨진 엄청난 비밀··· 잭은 자신과 동료들의 죽음에 맞서 살아남기 위해 사투를 시작하는데···<br><br><br>지금, 모든 것을 압도할 거대한 전투가 펼쳐진다!','https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000079/79598/79598145202_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000079/79598/79598145201_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000079/79598/79598145200_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000079/79598/79598145199_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000079/79598/79598145195_727.jpg','https://www.youtube.com/embed/aoT4RjVq41Y?controls=0,https://www.youtube.com/embed/5RWz1ostEt8?controls=0,https://www.youtube.com/embed/Hgeu5rhoxxY?controls=0'),('1037','인셉션','판타지','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000039/39054/39054_1000.jpg','Inception','크리스토퍼 놀란','레오나르도 디카프리오, 와타나베 켄, 마리옹 꼬띠아르','12세 이상','2010-07-21','드림머신이라는 기계로 타인의 꿈과 접속해 생각을 빼낼 수 있는 미래사회.<br>‘돔 코브’(레오나르도 디카프리오)는 생각을 지키는 특수보안요원이면서 또한 최고의 실력으로 생각을 훔치는 도둑이다.<br>우연한 사고로 국제적인 수배자가 된 그는 기업간의 전쟁 덕에 모든 것을 되찾을 수 있는 기회를 얻게 된다.<br>하지만 임무는 머릿속의 정보를 훔쳐내는 것이 아니라, 반대로 머릿속에 정보를 입력시켜야 하는 것!<br>그는 ‘인셉션’이라 불리는 이 작전을 성공시키기 위해 최강의 팀을 조직한다.<br>불가능에 가까운 게임, 하지만 반드시 이겨야만 한다!','https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000039/39054/39054114841_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000039/39054/39054114839_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000039/39054/39054114837_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000039/39054/39054114827_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000039/39054/39054114814_727.jpg','https://www.youtube.com/embed/hx1fqhNoH8A?controls=0,https://www.youtube.com/embed/Uj7z5HH9nfs?controls=0,https://www.youtube.com/embed/mucmHmjU9YE?controls=0'),('1038','메멘토','판타지','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000005/5003/5003_1000.jpg','','','','','','','',''),('1039','스타워즈 - 깨어난 포스','판타지','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000078/78499/78499_1000.jpg','Star Wars - The Force Awakens','J.J 에이브럼스','데이지 리틀리, 존 보예가, 오스카 아이삭','12세 이상','2015-12-17','새로운 전설을 그려나가게 될 포스의 선택을 받은 ‘레이’ 와 포스의 기운을 모아 정의를 위해 싸우는 ‘핀’<br><br>그리고 저항군 최고의 파일럿 ‘포’가 함께 힘을 모아 우주의 정의를 위해 싸운다.','https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000078/78499/78499133108_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000078/78499/78499133107_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000078/78499/78499133106_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000078/78499/78499133105_727.jpg,https://img.cgv.co.kr/Movie/Thumbnail/StillCut/000078/78499/78499133104_727.jpg','https://www.youtube.com/embed/G7VijpXyAXI?controls=0,https://www.youtube.com/embed/MqfAMn04xX4?controls=0,https://www.youtube.com/embed/0FnBWN-DzEQ?controls=0'),('1040','나니아 연대기 - 새벽출정호의 항해','판타지','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000039/39394/39394_1000.jpg','','','','','','','',''),('1041','여름이야기','로맨틱','https://t1.daumcdn.net/movie/f5b9aa5ab1b58241b4c16792c15041d786ad6bce','A Summer\'s Tale, Conte d\'été','에릭 로메르','멜빌 푸포, 아만다 랑글레','','','','',''),('1042','중경삼림','로맨틱','https://t1.daumcdn.net/movie/b491e00f195f70fe69364c79cd1ef40224b19608','','','','','','','',''),('1043','컴온 컴온','드라마','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85920/85920_1000.jpg','','','','','','','',''),('1045','헤어질 결심','드라마','https://img.cgv.co.kr/Movie/Thumbnail/Poster/000085/85852/85852_1000.jpg','','','','','','','',''),('1046','애프터 양','드라마','https://img.dtryx.com/poster/2022/05/5433D630-28D1-4907-96A8-AACD12AF11C4.small.jpg','','','','','','','','');
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-22 16:57:41
